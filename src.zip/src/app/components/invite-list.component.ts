import { Component, OnInit } from '@angular/core';
import { Item, ItemService } from '../../services/invite.service';


@Component({
  selector: 'invite-list',
  templateUrl: './invite-list.component.html'
})
export class InviteListComponent implements OnInit {
  items: Item[] = [];
  newItemTitle = '';

  constructor(private itemService: ItemService) {}

  ngOnInit(): void {
    this.loadItems();
  }

  loadItems(): void {
    this.itemService.getItems().subscribe(data => this.items = data);
  }

  addItem(): void {
    if (!this.newItemTitle.trim()) return;
    const item = { title: this.newItemTitle };
    this.itemService.addItem(item).subscribe(added => {
      this.items.push(added);
      this.newItemTitle = '';
    });
  }
}